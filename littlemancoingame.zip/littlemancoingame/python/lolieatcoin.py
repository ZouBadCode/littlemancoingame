import pygame
import random
import sys
import time
import pandas as pd
#色
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)


# 定義小人類別
class Player(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("player.png")  # 小人圖片
        self.image = pygame.transform.scale(self.image, (30, 30))
        self.rect = self.image.get_rect()
        self.rect.x = 0
        self.rect.y = 0
        self.rect.center = (window_width // 2, window_height // 2)

    def update(self):
        # 取得使用者的輸入
        key_state = pygame.key.get_pressed()
        if key_state[pygame.K_LEFT]:
            self.rect.x -= 5
        if key_state[pygame.K_RIGHT]:
            self.rect.x += 5
        if key_state[pygame.K_UP]:
            self.rect.y -= 5
        if key_state[pygame.K_DOWN]:
            self.rect.y += 5

        # 確保小人不會超出視窗範圍
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > window_width:
            self.rect.right = window_width
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > window_height:
            self.rect.bottom = window_height


# 定義金幣類別
class Coin(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("coin.png")  # 金幣圖片
        self.image = pygame.transform.scale(self.image,
                                            (30, 30))  # 縮放金幣圖片的寬度和高度
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, window_width - self.rect.width)
        self.rect.y = random.randint(0, window_height - self.rect.height)


#炸彈
class Bomb(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("bomb.png")  # 炸彈圖片
        self.image = pygame.transform.scale(self.image,
                                            (30, 30))  # 縮放金幣圖片的寬度和高度
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, window_width - self.rect.width)
        self.rect.y = random.randint(0, window_height - self.rect.height)
        if not player.rect.colliderect(self.rect.x, self.rect.y):
            return


# 定义按钮类
class Button:

    def __init__(self, x, y, width, height, color, text):
        self.rect = pygame.Rect(x, y, width, height)
        self.color = color
        self.text = text

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect)
        font = pygame.font.Font(None, 30)
        text = font.render(self.text, True, BLACK)
        text_rect = text.get_rect(center=self.rect.center)
        surface.blit(text, text_rect)

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)


class restart:

    def __init__(self, x, y, width, height, color, text):
        self.rect = pygame.Rect(x, y, width, height)
        self.color = color
        self.text = text

    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.rect)
        font = pygame.font.Font(None, 30)
        text = font.render(self.text, True, BLACK)
        text_rect = text.get_rect(center=self.rect.center)
        surface.blit(text, text_rect)

    def is_clicked(self, pos):
        return self.rect.collidepoint(pos)


while (True):
    # 初始化Pygame
    pygame.init()

    # 視窗大小
    window_width = 1280
    window_height = 720

    # 顏色
    black = (0, 0, 0)
    white = (255, 255, 255)
    gold = (255, 215, 0)

    # 建立遊戲視窗
    window = pygame.display.set_mode((window_width, window_height))
    pygame.display.set_caption("小人吃金幣")

    clock = pygame.time.Clock()

    # 創建遊戲物件群組
    all_sprites = pygame.sprite.Group()
    coins = pygame.sprite.Group()
    bombs = pygame.sprite.Group()
    # 建立小人物件
    player = Player()
    all_sprites.add(player)

    # 產生金幣物件
    for i in range(10):
        coin = Coin()
        all_sprites.add(coin)
        coins.add(coin)
    #炸彈產生
    for i in range(50):
        bomb = Bomb()
        all_sprites.add(bomb)
        bombs.add(bomb)
    # 讀取最高分
    def load_highscore():
        try:
            with open("highscore.txt", "r") as file:
                highscore = int(file.read())
        except FileNotFoundError:
            highscore = 0
        return highscore

    # 儲存最高分
    def save_highscore(highscore):
        with open("highscore.txt", "w") as file:
            file.write(str(highscore))

    # 載入最高分
    highscore = load_highscore()

    # 建立記分板字型
    font = pygame.font.Font(None, 36)

    # 開始畫面迴圈
    show_start_screen = True

    while show_start_screen:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                show_start_screen = False

        window.fill(black)
        start_text = font.render("Press any key to start", True, white)
        window.blit(start_text,
                    (window_width // 2 - start_text.get_width() // 2,
                     window_height // 2))
        pygame.display.flip()
        clock.tick(60)

    # 遊戲迴圈
    running = True
    score = 0

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        all_sprites.update()

        # 檢查小人是否碰到金幣
        hits = pygame.sprite.spritecollide(player, coins, True)
        for hit in hits:
            score += 1
            print("Score:", score)
        #碰到炸彈
        if pygame.sprite.spritecollide(player, bombs, True):
            print("Game Over")
            running = False
        # 檢查金幣數量，如果不足則新增金幣物件
        while len(coins) < 10:
            coin = Coin()
            all_sprites.add(coin)
            coins.add(coin)

        # 檢查炸彈數量，如果不足則新增炸彈物件
        while len(bombs) < score + 50:
            bomb = Bomb()
            for j in range(30):
                all_sprites.add(bomb)
                bombs.add(bomb)
        # 繪製遊戲畫面
        window.fill(black)
        all_sprites.draw(window)

        # 顯示分數
        font = pygame.font.Font(None, 36)
        text = font.render("Score: " + str(score), True, white)
        window.blit(text, (10, 10))
        # 更新最高分
        if score > highscore:
            highscore = score
            save_highscore(highscore)

        # 畫記分板
        text = font.render("Score: " + str(score), True, white)
        window.blit(text, (10, 10))
        text = font.render("Highscore: " + str(highscore), True, white)
        window.blit(text, (10, 50))
        # 更新視窗
        pygame.display.flip()

        # 控制遊戲更新速度
        clock.tick(60)

    close_button = Button(350, 250, 100, 50, RED, "Close")
    restartbutton = restart(650, 250, 100, 50, RED, "Restart")
    a = 0
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if close_button.is_clicked(mouse_pos):
                    pygame.quit()
                    sys.exit()
                elif restartbutton.is_clicked(mouse_pos):
                    a = 1
                    break
        if a == 1:
            break

        window.fill(black)
        close_button.draw(window)
        restartbutton.draw(window)
        pygame.display.flip()
        clock.tick(60)
